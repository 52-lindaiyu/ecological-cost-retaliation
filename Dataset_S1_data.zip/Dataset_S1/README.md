# Dataset S1: numerical outputs and construction checks

## Study

The ecological cost of retaliation bounds decentralised reciprocity in commons with tipping points.

This data-only archive contains the recorded simulation and numerical-control outputs supporting the manuscript, together with deterministic construction checks. File paths retain the structure of Dataset S1. Computation and analysis code is maintained separately in the project repository:

https://github.com/52-lindaiyu/ecological-cost-retaliation

## Contents

- `source/`: 28 CSV and JSON files containing recorded numerical curves, control calculations, seed-level learning outcomes and evolutionary outcomes.
- `derived/construction_checks.csv`: signed deterministic margins supporting the construction checks discussed in SI Note S4.

All 29 data files are copied byte-for-byte from the complete Dataset S1. CSV files have header rows. Data are simulated rather than empirical observations. Stock is normalised by carrying capacity K=1; the baseline effort cap and price are 1. Parameter and outcome columns retain their recorded names. Complete model and experiment definitions are in the manuscript and SI.

## Data-to-paper map

File names in the table are relative to `source/`, except the final row.

| Paper items | Data files |
|---|---|
| Fig. 1: regeneration, effort bifurcation, sustainable rent and regimes | `phi_map.csv`, `effort_bifurcation.csv`, `rent_curve.csv`, `theory_grid.csv` |
| Fig. 2; Tables S1 and S4: sanction-window calculations | `theory_theta_slice.csv`, `theory_N_slice.csv`, `ceiling_check.csv`, `exploit_theta_xhold.csv`, `exploit_N_xhold.csv` |
| Table 1; Table S2; Fig. 3: rule comparison and baseline quantities | `rule_library.csv`, `paper_numbers.json` |
| Table S3: catchability, fragility and monitoring-noise controls | `exploit_q_control.csv`, `review_fragility_control.csv`, `review_monitoring_noise.csv` |
| Fig. 4; Fig. S1; Tables S7 and S8: learning outcomes and replications | `marl_objective_sweep.csv`, `review_lambda_fine.csv`, `review_lambda_theta8.csv`, `review_group_size8_rationed.csv` |
| Fig. 5; Table S13: evolutionary trajectories, final shares and basins | `evo_trajectories.json`, `evo_tournament.csv`, `evo_basins.csv` |
| Table S5: distilled contestants and their evaluation | `contestants_certified.csv`, `distilled_rules.json`, `paper_numbers.json` |
| Fig. S2; Table S6: main robustness grid | `robustness_main.csv` |
| Table S9; Note S3: simultaneous defectors | `si_k_mutants.csv` |
| Table S10: discretisation checks | `si_grid_convergence.csv` |
| Table S11; Note S5: planner calculation | `planner_certificate.csv` |
| Table S12; Note S2: steady-effort safety margins | `safety_margin_sensitivity.csv` |
| Note S4: construction checks | `../derived/construction_checks.csv` |

## Numerical conventions

- `rent_self` is deterministic long-run self-play rent. `v_self` is the annuity-equivalent self-play value on the finite MDP. Exploitability subtracts that matched MDP value from the best-response value (`br` or `br_value`).
- Numerical payoff classification uses unrounded exploitability and the recorded `tol_bound` (p times monitoring tolerance). Worst-case collapse is within 200 periods, with cutoff 0.01. These are finite-model quantities.
- `robustness_main.csv` contains the complete 288-cell main grid, all at zero execution error, including failed cells. A rule's joint pass rate is the fraction passing both payoff and collapse criteria. The two conditional steward counts quoted in the paper are 25/36 and 16/18.
- The initial reward sweep has five training seeds per reward condition and 300 evaluation rollouts per seed. The dual reward weight is 0.8. Fine-prosociality replications have sixteen seeds per condition; fragility and group-size replications have eight. The latter replication sweeps use 200 evaluation rollouts per seed. Training regeneration shocks are uniform; historical initial learning evaluations use untruncated normal shocks, while the rationed N=8,12 re-runs use normal shocks clipped at +/-3.
- The five historical `-inf` entries in the initial sweep's `r2` column denote undefined fit scores with a zero denominator. Exclude them when summarising fit scores and report the valid count. Negative finite scores remain valid. Source values are retained as recorded.
- Historical column names `hi_exact` and `width_exact` in `ceiling_check.csv` refer to numerically optimised ceilings and widths. The paper distinguishes these from closed-form benchmarks.
- Evolutionary final shares are generation-150 values, summarised over twelve replicates per fragility. Each replicate's terminal collapse rate averages freshly started games over its last twenty generations. Basin runs last eighty generations, with four replicates per cell. Final share and terminal collapse rate are different statistics.

## Construction-check fields

`axis` and `value` identify the parameter varied. `y_star`, `x_star` and `pi_star` describe the optimal steady target; `floor` and `upper_fixed_point` give the unilateral-harvester fixed points. `closed_ceiling` is the closed-form deterrence benchmark; `hold` is the midpoint when that closed-form window is non-empty.

The signed margins are:

- `condition1_margin`: effort cap minus maximum required cooperative effort.
- `condition2_lower_margin`: hold level minus ecological floor.
- `condition2_upper_margin`: upper fixed point minus hold level.
- `condition3_margin`: total resident effort capacity minus required resident sanction effort.
- `condition5_margin`: minimum next stock after a maximal one-period raid minus ecological floor.

Positive margins satisfy the corresponding deterministic inequality. Blank fields indicate that the associated fixed point or hold level is unavailable for that parameter value. These margins accompany the theorem's other conditions and the separate finite-model payoff and noisy-collapse calculations; they do not substitute for them.
